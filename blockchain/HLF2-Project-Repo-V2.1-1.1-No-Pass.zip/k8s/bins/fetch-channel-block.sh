#!/bin/sh
peer channel fetch 0 ../config/airlinechannel.block -o $ORDERER_ADDRESS -c airlinechannel