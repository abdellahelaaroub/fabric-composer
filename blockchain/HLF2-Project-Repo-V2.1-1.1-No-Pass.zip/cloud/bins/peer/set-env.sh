# EDIT THIS To Control the Peer Setup
export ORDERER_ADDRESS=54.84.11.141:7050


export FABRIC_LOGGING_SPEC=info

export CORE_PEER_LOCALMSPID=<<<SET THIS UP BASED on Org  AcmeMSP or BudgetMSP>>>

# Admin identity used for commands
export CORE_PEER_MSPCONFIGPATH=./msps/admin