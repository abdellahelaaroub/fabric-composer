

Policy.0/configtx.yaml
======================
This is a minimilistic configuration that does not have any policies defined in it.
On execution of the orderer/multi-org/init.sh multiple warnings wil be generated as the default policies are deprecated

Exercise
========
1. Initialize the Orderer with policy.0 configtx.yaml
2. In the Peer folder 