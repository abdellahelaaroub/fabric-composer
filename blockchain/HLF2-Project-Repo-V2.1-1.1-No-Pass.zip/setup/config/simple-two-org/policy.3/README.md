# R1.2 AdminPrincipals specifications is deprecated
The configtx YAML in this folder is updated

