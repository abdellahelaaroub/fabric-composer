# Generate the crypto
cryptogen generate --config=crypto-config.yaml --output=crypto-config

# cp-config.sh
Initializes the config files - use it if you have made changes to the YAML