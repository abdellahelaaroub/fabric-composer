# Kills all running peer instances
# May show a message "peer: no process found" - please ignore it
sudo killall peer

echo "Done."
