# Simply kills the peer process
echo 'Killing the peer processes'
killall peer
