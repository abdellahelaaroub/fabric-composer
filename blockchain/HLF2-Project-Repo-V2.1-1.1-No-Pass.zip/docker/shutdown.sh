#!/bin/bash
#Launches the setup
docker-compose -f ./config/docker-compose-base.yaml down